#!/usr/bin/env bash
# cleanup.sh — teardown for the HPC bootcamp cluster.
#
# Run from the repository root (directory containing Vagrantfile):
#   ./scripts/cleanup.sh
#
# Designed to paste-safely in Git Bash on Windows: no heredocs, no
# complex quoting, no Unicode glyphs. Every command is independent
# and resumes if earlier ones fail.
#
# What gets destroyed:
#   - compute01, compute02  (VirtualBox VMs + their disks)
#   - head                  (via vagrant destroy -f)
#   - .vagrant/             (Vagrant working state)
#   - compute0*.console.log (serial-console log files)
#
# What's preserved:
#   - Rocky 9.7 base box cache (~/.vagrant.d/boxes/)
#   - Git repo and tags
#   - All RUNBOOK / script files

set +e  # keep going even if an individual step fails

echo "=== cleanup.sh: bootcamp teardown ==="
echo

echo "--- compute01 ---"
VBoxManage controlvm compute01 poweroff 2>/dev/null
sleep 1
VBoxManage unregistervm compute01 --delete 2>/dev/null && echo "compute01 removed" || echo "compute01 not present"

echo "--- compute02 ---"
VBoxManage controlvm compute02 poweroff 2>/dev/null
sleep 1
VBoxManage unregistervm compute02 --delete 2>/dev/null && echo "compute02 removed" || echo "compute02 not present"

echo
echo "--- head (via vagrant) ---"
vagrant destroy -f

echo
echo "--- host-side scratch ---"
rm -f compute01.console.log compute02.console.log
rm -rf .vagrant

echo
echo "--- final state ---"
echo "registered VMs:"
VBoxManage list vms
echo
echo "done."
