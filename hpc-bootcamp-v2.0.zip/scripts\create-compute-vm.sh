#!/usr/bin/env bash
# create-compute-vm.sh — create a diskless PXE-booting compute VM in VirtualBox.
#
# Runs on the Windows host (Git Bash / WSL), NOT inside the head VM.
# VBoxManage must be on PATH; confirmed by HOST-PREP.md.
#
# Usage: ./create-compute-vm.sh <node-number>
#   where <node-number> is 1 or 2 (matching compute01 / compute02).
#
# The VM is created with:
#   - No disk (diskless — root filesystem comes from Warewulf PXE)
#   - 4 GB RAM, 2 vCPU (the tmpfs root needs ~1.4 GB; default tmpfs size
#     is half of RAM, so 2 GB isn't enough — compute would OOM during image
#     extraction. See TRIALS.md.)
#   - ich9 + ioapic + hpet firmware customizations (same rationale as head;
#     see STACK-DECISIONS.md)
#   - NIC1 on VirtualBox internal network "hpc-mgmt" with a pinned MAC that
#     Warewulf's node definition references (nodes.conf hwaddr field)
#   - NIC2 on VirtualBox internal network "hpc-data" (NFS + MPI fabric)
#   - Boot order: network only (no disk, no CD)
#   - Serial console redirected to compute0N.console.log for first-boot
#     debugging (kernel args include console=ttyS0,115200 from the WW profile)

set -euo pipefail

NODE_NUM="${1:-}"
if [[ -z "$NODE_NUM" || ! "$NODE_NUM" =~ ^[12]$ ]]; then
  echo "Usage: $0 <node-number: 1 or 2>" >&2
  exit 1
fi

VM_NAME="compute0${NODE_NUM}"
MAC_MGMT="525400C0010${NODE_NUM}"   # hpc-mgmt NIC — matches wwctl node hwaddr
MAC_DATA="525400D0010${NODE_NUM}"   # hpc-data NIC — MPI/NFS fabric

if ! command -v VBoxManage >/dev/null 2>&1; then
  echo "VBoxManage not found on PATH." >&2
  echo "Re-run HOST-PREP.md step 6 (install VirtualBox) and open a fresh shell." >&2
  exit 2
fi

# Idempotent: if the VM already exists, shut it down and remove it.
if VBoxManage list vms | grep -qE "\"${VM_NAME}\""; then
  echo "==> ${VM_NAME} already exists; unregistering"
  VBoxManage controlvm "${VM_NAME}" poweroff 2>/dev/null || true
  sleep 1
  VBoxManage unregistervm "${VM_NAME}" --delete
fi

echo "==> Creating ${VM_NAME}"
VBoxManage createvm --name "${VM_NAME}" --ostype RedHat_64 --register

echo "==> CPU, memory, firmware"
VBoxManage modifyvm "${VM_NAME}" \
  --cpus 2 \
  --memory 4096 \
  --chipset ich9 \
  --ioapic on \
  --hpet on \
  --firmware bios

echo "==> NIC1 (hpc-mgmt, PXE boot)"
VBoxManage modifyvm "${VM_NAME}" \
  --nic1 intnet \
  --intnet1 hpc-mgmt \
  --macaddress1 "${MAC_MGMT}" \
  --nictype1 82540EM \
  --nicbootprio1 1

echo "==> NIC2 (hpc-data)"
VBoxManage modifyvm "${VM_NAME}" \
  --nic2 intnet \
  --intnet2 hpc-data \
  --macaddress2 "${MAC_DATA}" \
  --nictype2 82540EM

echo "==> Boot order: network only (diskless)"
VBoxManage modifyvm "${VM_NAME}" \
  --boot1 net \
  --boot2 none \
  --boot3 none \
  --boot4 none

echo "==> Serial console -> ${VM_NAME}.console.log"
VBoxManage modifyvm "${VM_NAME}" \
  --uart1 0x3f8 4 \
  --uartmode1 file "${VM_NAME}.console.log"

echo "==> Starting ${VM_NAME} (headless)"
VBoxManage startvm "${VM_NAME}" --type headless

cat <<EOF

${VM_NAME} is booting. Watch its PXE + kernel boot with:

    tail -f ${VM_NAME}.console.log

From head (\`vagrant ssh\`), confirm it shows up:

    sudo wwctl node status
    sinfo
EOF
